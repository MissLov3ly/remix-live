"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([[3465],{

/***/ 13465:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("pragma circom 2.0.0;\n\ntemplate Multiplier2() {\n    signal input a;\n    signal input b;\n    signal output c;\n    c <== a*b;\n }\n\n component main = Multiplier2();\n ");

/***/ })

}]);
//# sourceMappingURL=3465.plugin-etherscan.1701431369727.js.map